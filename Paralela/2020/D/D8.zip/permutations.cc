#include <algorithm>
#include <iostream>
#include <string>
#include <vector>

using namespace std;

struct IsWhitespace {
    template <typename Char> auto
    operator()(Char c) const -> bool {
        return (c == ' ' )
            || (c == '\n')
            || (c == '\r')
            || (c == '\t')
            || (c == '\f')
            || (c == '\v');
    }
} ;

template <typename String> inline auto
remove_whitespaces (String text) -> String {
    text.erase(std::remove_if(text.begin(), text.end(), IsWhitespace()), text.end());
    return text;
}

template <typename String, typename InStream> inline auto
read_text_from_stdin (InStream& in) -> String {
    std::istreambuf_iterator<char>begin(in), end;
    std::string text(begin, end);
    text = remove_whitespaces(text);
    return text;
}

int main() {
    string str = read_text_from_stdin<std::string>(std::cin);
    string output = "";
    cin >> str;

    sort(str.begin(), str.end());
    
    size_t n = str.size();

    bool used_letters[256];

    for (int i = 0; i < 256; ++i)
        used_letters[i] = false;

    #pragma omp parallel for ordered
    for (size_t i = 0; i < n; ++i) {
        vector<string> v;
        bool dont_work = false;

        #pragma omp critical
        {
            if (used_letters[(int)str[i]])
                dont_work = true;
            else
                used_letters[(int)str[i]] = true;
        }

        if (dont_work)
            continue;

        string perm = str;
        swap(perm[0], perm[i]);
        sort(perm.begin() + 1, perm.end());

        do
            v.emplace_back(perm);
        while (next_permutation(perm.begin() + 1, perm.end()));
        
        #pragma omp ordered
        {
            for (auto& it : v) {
                output += "[ ";

                for (auto& c : it) {
                    output += c;
                    output += ' ';
                }

                output += "]\n";
            }
        }
    }

    cout << output;
}
